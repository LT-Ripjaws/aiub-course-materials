import java.lang.*;

public class Start{
	
	public static void main(String[] args)
	{
		student s1=new student("shakib",40,555,3.3);
		s1.view();
		teacher t1=new teacher("tamim",50,665);
		t1.view();
	}
	
}