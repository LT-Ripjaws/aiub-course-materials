import java.lang.*;
import javax.swing.*;

public class Start
{
	public static void main(String[] args)
	{
		framedemo f1= new framedemo();
		f1.setVisible(true);
	}
}